<?php
class ControllerExtensionPaymentGlobalpay extends Controller
{
    public function index()
    {
        $this->load->model('checkout/order');

        $this->load->language('extension/payment/globalpay');

        $data['button_confirm'] = $this->language->get('button_confirm');
        $data['text_testmode'] = $this->language->get('text_testmode');
        $data['livemode'] = $this->config->get('payment_globalpay_live');

        if ($this->config->get('payment_globalpay_live')) {
            $authurl = "http://globalpayauthserver.azurewebsites.net/connect/token";
            $baseurl = "http://globalpay.azurewebsites.net";
            $clientId = $this->config->get('payment_globalpay_live_client_id');
            $clientSecret = $this->config->get('payment_globalpay_live_client_id');
        } else {
            $authurl = "http://globalpayauthserver.azurewebsites.net/connect/token";
            $baseurl = "http://globalpay.azurewebsites.net";
            $clientId = $this->config->get('payment_globalpay_live_client_id');
            $clientSecret = $this->config->get('payment_globalpay_live_client_id');
        };

        //Client Authentication
        $body = array('client_id'=>$clientId,
            'grant_type'=>"client_credentials",
            'client_secret'=>$clientSecret);

        $postvars = '';
        foreach($body as $key=>$value) {
            $postvars .= $key . "=" . $value . "&";
        }

        $ch = curl_init();
        curl_setopt($ch,CURLOPT_URL,$authurl);
        curl_setopt($ch,CURLOPT_POST, 1);
        curl_setopt($ch,CURLOPT_POSTFIELDS,$postvars);
        curl_setopt($ch,CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch,CURLOPT_CONNECTTIMEOUT ,3);
        curl_setopt($ch,CURLOPT_TIMEOUT, 20);

        $response = curl_exec($ch);
        $err = curl_error($ch);

        $responseObject = json_decode($response, true);

        if (!isset($responseObject['error'])) {
            $access_token = $responseObject['access_token'];
            $data['error'] = false;
        } else {
            $data['error_detail'] = 'Access_token error:' . $responseObject['error'];
            $data['error'] = true;
        };


        //Register Transaction
        $order_info = $this->model_checkout_order->getOrder($this->session->data['order_id']);
        $customer = array('email'=> $order_info['email'],
            'firstname'=> $order_info['payment_firstname'],
            'lastname'=> $order_info['payment_lastname'],
            'mobile'=>$order_info['telephone']);

        $product = array('name'=> 'opencart_order',
            'unitprice'=> intval($order_info['total'] * 100),
            'quantity'=>"1");

        $fields = array( 'returnurl'=>$this->url->link('extension/payment/globalpay/callback', 'SSL'),
            'customerip'=>'127.0.0.1',
            'merchantid'=>$this->config->get('payment_globalpay_merchant_id'),
            'merchantreference'=>$this->session->data['order_id'],
            'description'=>"Opencart 3.0 transaction",
            'totalamount'=>intval($order_info['total'] * 100),
            'paymentmethod'=>'card',
            'transactionType'=>'Payment',
            'connectionmode'=>'redirect',
            'currencycode'=>'566',
            'customer'=>$customer,
            'product'=>array($product));

        $payload = json_encode($fields);
        $ch2 = curl_init();
        curl_setopt($ch2,CURLOPT_URL,$baseurl . "/api/v3/Payment/SetRequest");
        curl_setopt($ch2,CURLOPT_POST, 1);
        curl_setopt($ch2,CURLOPT_POSTFIELDS,$payload);
        curl_setopt($ch2,CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch2,CURLOPT_CONNECTTIMEOUT ,3);
        curl_setopt( $ch2, CURLOPT_HTTPHEADER, array('Content-Type:application/json',
            "Authorization: Bearer {$access_token}",));
        curl_setopt($ch,CURLOPT_TIMEOUT, 20);
        $response = curl_exec($ch);
        $responseObject = json_encode($response);

        if ($responseObject['status']['statusCode']=="201") {
            $data['redirect_url'] = $responseObject['redirectUri'];
            $data['error'] = false;
        } else {
            $data['error'] = true;
            $data['error_detail'] = 'Register transaction error:' . $responseObject['error'];
        };

        return $this->load->view('extension/payment/globalpay', $data);
    }

    private function query_api_transaction_verify($reference)
    {
        if ($this->config->get('payment_globalpay_live')) {
            $authurl = "http://globalpayauthserver.azurewebsites.net/connect/token";
            $baseurl = "http://globalpay.azurewebsites.net";
            $clientId = $this->config->get('payment_globalpay_live_client_id');
            $clientSecret = $this->config->get('payment_globalpay_live_client_id');
        } else {
            $authurl = "http://globalpayauthserver.azurewebsites.net/connect/token";
            $baseurl = "http://globalpay.azurewebsites.net";
            $clientId = $this->config->get('payment_globalpay_live_client_id');
            $clientSecret = $this->config->get('payment_globalpay_live_client_id');
        };

        //Client Authentication
        $fields = array('merchantid'=> $this->config->get('payment_globalpay_merchant_id'),
            'merchantreference'=> $this->session->data['order_id'],
            'transactionreference'=> $reference);


        $payload = json_encode($fields);
        $ch = curl_init();
        curl_setopt($ch,CURLOPT_URL,$baseurl . "/api/v3/Payment/Retrieve");
        curl_setopt($ch,CURLOPT_POST, 1);
        curl_setopt($ch,CURLOPT_POSTFIELDS,$payload);
        curl_setopt($ch,CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch,CURLOPT_CONNECTTIMEOUT ,3);
        curl_setopt($ch,CURLOPT_TIMEOUT, 20);

        $response = curl_exec($ch);
        $err = curl_error($ch);
        $responseObject = json_decode($response, true);

        return $responseObject;
    }

    private function redir_and_die($url, $onlymeta = false)
    {
        if (!headers_sent() && !$onlymeta) {
            header('Location: ' . $url);
        }
        echo "<meta http-equiv=\"refresh\" content=\"0;url=" . addslashes($url) . "\" />";
        die();
    }


    public function callback()
    {

        if (isset($this->request->get['transactionreference'])) {
            $trxref = $this->request->get['transactionreference'];
            $order_id = $this->session->data['order_id'];
            // if no dash were in transation reference, we will have an empty order_id
            if (!$order_id) {
                $order_id = 0;
            }

            $this->load->model('checkout/order');

            $order_info = $this->model_checkout_order->getOrder($order_id);

            if ($order_info) {
                if ($this->config->get('payment_globalpay_debug')) {
                    $this->log->write('globalpay :: CALLBACK DATA: ' . print_r($this->request->get, true));
                }

                // Callback globalpay to get real transaction status
                $ps_api_response = $this->query_api_transaction_verify($trxref);

                $order_status_id = $this->config->get('config_order_status_id');

                if (array_key_exists('status', $ps_api_response) && array_key_exists('status', $ps_api_response['statusCode']) && ($ps_api_response['status']['statusCode'] === '200')) {
                    $order_status_id = $this->config->get('payment_globalpay_approved_status_id');
                    $redir_url = $this->url->link('checkout/success');
                } else if (array_key_exists('data', $ps_api_response) && array_key_exists('status', $ps_api_response['data']) && ($ps_api_response['data']['status'] != '200')) {
                    $order_status_id = $this->config->get('payment_globalpay_declined_status_id');
                    $redir_url = $this->url->link('checkout/checkout', '', 'SSL');
                } else {
                    $order_status_id = $this->config->get('globalpay_error_status_id');
                    $redir_url = $this->url->link('checkout/checkout', '', 'SSL');
                }

                $this->model_checkout_order->addOrderHistory($order_id, $order_status_id);
                $this->redir_and_die($redir_url);
            }

        }

    }
}



