<?php
// Text
$_['text_title'] = 'Globalpay';
$_['text_testmode'] = 'Warning: The payment gateway is in \'Test Mode\'. Only a  test card can be used.';
// Heading
$_['heading_title'] = 'globalpay';

// Text
$_['text_payment'] = 'Payment';
$_['text_success'] = 'Success: You have modified globalpay details!';
$_['text_edit'] = 'Edit globalpay';
$_['text_globalpay'] = '<a target="_BLANK" href="http://www.globalpay.com"><img src="view/image/payment/globalpay.gif" alt="globalpay" title="globalpay" style="border: 1px solid #cccccc;" /></a>';
$_['text_pay'] = 'Pay';
$_['text_disable_payment'] = 'Disable Payment Method';

// Entry
$_['entry_live_client_secret'] = 'Live Client Secret:';
$_['entry_live_client_id'] = 'Live Client Id:';
$_['entry_test_client_secret'] = 'Test Client Secret:';
$_['entry_test_client_id'] = 'Test Client Id:';

$_['entry_live'] = 'Live Mode';
$_['entry_debug'] = 'Debug Mode';
$_['entry_total'] = 'Total';
$_['entry_approved_status'] = 'Approved Status';
$_['entry_declined_status'] = 'Declined Status:';
$_['entry_error_status'] = 'Error Status:';
$_['entry_geo_zone'] = 'Geo Zone';
$_['entry_status'] = 'Status';
$_['entry_sort_order'] = 'Sort Order';

// Tab
$_['tab_general'] = 'General';
$_['tab_order_status'] = 'Order Status';

// Help
$_['help_live'] = 'Use the live mode to process transactions? Request Go Live on the globalpay Dashboard to get live keys.';
$_['help_debug'] = 'Logs additional information to the system log';
$_['help_total'] = 'The checkout total the order must reach before this payment method becomes active';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify the globalpay module!';
$_['error_test_keys'] = 'Both Test keys are required for test mode!';
$_['error_live_keys'] = 'Both Live keys are required for live mode!';