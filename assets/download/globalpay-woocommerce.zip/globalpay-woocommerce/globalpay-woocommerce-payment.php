<?php
/*
	Plugin Name: Globalpay WooCommerce Payment 
	Plugin URI:  http://www.globalpay.com
	Description: Globalpay WooCommerce Payment Plugin allows you to accept payment on your WooCommerce store via Visa Cards, Mastercards, Verve Cards and eTranzact.
	Version: 1.1.0
	Author: Electronic Settlements Limited
	Author URI: http://www.globalpay.com
	License: GPL-2.0+
 	License URI: http://www.gnu.org/licenses/gpl-2.0.txt

*/
if (!defined('ABSPATH'))
    exit;

add_action('plugins_loaded', 'woocommerce_globalpay_init', 0);

function woocommerce_globalpay_init()
{

    if (!class_exists('WC_Payment_Gateway')) return;

    /**
     * Gateway class
     */
    class WC_Globalpay_Gateway extends WC_Payment_Gateway
    {

        public function __construct()
        {
            global $woocommerce;

            //define and set generic variables
            $this->id = 'globalpay_gateway';
            $this->icon = apply_filters('woocommerce_globalpay_icon', plugins_url('assets/globalpay.gif', __FILE__));
            $this->has_fields = false;
            $this->baseurl_test = 'http://globalpay.azurewebsites.net';
            $this->baseurl_live = 'http://globalpay.azurewebsites.net';
            $this->authurl_test = 'http://globalpayauthserver.azurewebsites.net/connect/token';
            $this->authurl_live = 'http://globalpayauthserver.azurewebsites.net/connect/token';
            $this->notify_url = WC()->api_request_url('WC_Globalpay_Gateway');
            $this->method_title = 'Globalpay Payment Plugin';
            $this->method_description = 'Globalpay Payment Plugin allows you to receive eTransact,Mastercard, Verve Card and Visa Card Payments On your WooCommerce Powered Site.';


            // Load the form fields.
            $this->init_form_fields();

            // Load the settings.
            $this->init_settings();


            // Define user set variables
            $this->MerchantId = $this->get_option('MerchantId');
            $this->ClientIdLive = $this->get_option('ClientIdLive');
            $this->ClientIdTest = $this->get_option('ClientIdTest');
            $this->ClientSecretLive = $this->get_option('ClientSecretLive');
            $this->ClientSecretTest = $this->get_option('ClientSecretTest');
            $this->Mode = $this->get_option('Mode');

            //Actions
            add_action('woocommerce_receipt_globalpay_gateway', array($this, 'receipt_page'));
            add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));

            // Payment listener/API hook
            add_action('woocommerce_api_wc_globalpay_gateway', array($this, 'check_globalpay_response'));

            // Check if the gateway can be used
            if (!$this->is_valid_for_use()) {
                $this->enabled = false;
            }
        }

        public function is_valid_for_use()
        {

            if (!in_array(get_woocommerce_currency(), array('NGN'))) {
                $this->msg = 'Globalpay doesn\'t support your store currency, set it to Nigerian Naira &#8358; <a href="' . get_bloginfo('wpurl') . '/wp-admin/admin.php?page=wc_settings&tab=general">here</a>';
                return false;
            }

            return true;
        }

        /**
         * Admin Panel Options
         **/
        public function admin_options()
        {
            echo '<h3>Globalpay Payment Plugin</h3>';
            echo '<p>Globalpay Payment Plugin allows you to accept payment through various channels such as Mastercard, Verve Cards, eTranzact and Visa cards.</p>';


            if ($this->is_valid_for_use()) {

                echo '<table class="form-table">';
                $this->generate_settings_html();
                echo '</table>';
            } else { ?>
                <div class="inline error"><p><strong>Globalpay Payment Plugin
                            Disabled</strong>: <?php echo $this->msg ?></p></div>

            <?php }
        }


        /**
         * Initialise Gateway Settings Form Fields
         **/
        function init_form_fields()
        {
            $this->form_fields = array(
                'enabled' => array(
                    'title' => 'Enable/Disable',
                    'type' => 'checkbox',
                    'label' => 'Enable Globalpay Payment Plugin',
                    'description' => 'Enable or disable the gateway.',
                    'desc_tip' => true,
                    'default' => 'yes'
                ),
                'Mode' => array(
                    'title' => 'Mode',
                    'type' => 'checkbox',
                    'label' => 'Check to switch to live Mode',
                    'description' => '***Do this only when you have been told to do so by our support team***',
                    'desc_tip' => false,
                    'default' => 'no'
                ),
                'MerchantId' => array(
                    'title' => 'Globalpay Merchant ID',
                    'type' => 'text',
                    'description' => 'Enter Your Globalpay Merchant ID',
                    'default' => '',
                    'desc_tip' => true
                ),
                'ClientSecretLive' => array(
                    'title' => 'Globalpay Client Secret live',
                    'type' => 'text',
                    'description' => 'Enter Your Live Client Secret',
                    'default' => '',
                    'desc_tip' => true
                ),
                'ClientSecretTest' => array(
                    'title' => 'Globalpay Client Secret Test',
                    'type' => 'text',
                    'description' => 'Enter Your Test Client Secret',
                    'default' => '',
                    'desc_tip' => true
                ),
                'ClientIdLive' => array(
                    'title' => 'Globalpay Client ID Live',
                    'type' => 'text',
                    'description' => 'Enter Your Live Client ID',
                    'default' => '',
                    'desc_tip' => true
                ),
                'ClientIdTest' => array(
                    'title' => 'Globalpay Client ID Test',
                    'type' => 'text',
                    'description' => 'Enter Your Test Client ID',
                    'default' => '',
                    'desc_tip' => true
                )
            );
        }

        /**
         * Get Globalpay Args for passing to Globalpay
         **/
        function get_globalpay_args($order)
        {
            global $woocommerce;

            $order_data = $order->get_data();
            $order_id = $order->get_id();


            $ceamt = $order_data['cart_tax'];
            $cemertid = $this->MerchantId;
            $cememo = "Payment for Order ID: $order_id on " . get_bloginfo('name');
            $cenurl = add_query_arg('wc-api', 'WC_Globalpay_Gateway', home_url('/'));
            $merchantId = $this->MerchantId;


            session_start();
            $_SESSION['order_id'] = $order_id;
            $_SESSION['urlmode'] = $this->Mode;

            if ($this->Mode == 'yes') {
                $authurl = $this->authurl_live;
                $baseurl = $this->baseurl_live;
                $clientId = $this->ClientIdLive;
                $clientSecret = $this->ClientSecretLive;
            } else {
                $authurl = $this->authurl_test;
                $baseurl = $this->baseurl_test;
                $clientId = $this->ClientIdTest;
                $clientSecret = $this->ClientSecretTest;
            };

            //Client Authentication
            $body = array('client_id' => $clientId,
                'grant_type' => "client_credentials",
                'client_secret' => $clientSecret);

            $postvars = '';
            foreach ($body as $key => $value) {
                $postvars .= $key . "=" . $value . "&";
            }

            $ch2 = curl_init();
            curl_setopt($ch2, CURLOPT_URL, $authurl);
            curl_setopt($ch2, CURLOPT_POST, 1);
            curl_setopt($ch2, CURLOPT_POSTFIELDS, $postvars);
            curl_setopt($ch2, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch2, CURLOPT_CONNECTTIMEOUT, 3);
            curl_setopt($ch2, CURLOPT_TIMEOUT, 20);

            $response = curl_exec($ch2);
            $err = curl_error($ch2);

            $responseObject = json_decode($response, true);

            if (!isset($responseObject['error'])) {
                $access_token = $responseObject['access_token'];
                $_SESSION['transref'] = $responseObject['TransactionReference'];
                $error = false;
            } else {
                $error_detail = 'Access_token error:' . $responseObject['error'];
                $error = true;
            };


            //Register Transaction
            $customer = array('email' => $order_data['billing']['email'],
                'firstname' => $order_data['billing']['first_name'],
                'lastname' => $order_data['billing']['last_name'],
                'mobile' => $order_data['billing']['phone']);

            $product = array('name' => 'woocommerce_order',
                'unitprice' => intval($ceamt * 100),
                'quantity' => "1");

            $fields = array('returnurl' => $cenurl,
                'customerip' => '127.0.0.1',
                'merchantid' => $cemertid,
                'merchantreference' => $order_id,
                'description' => $cememo,
                'totalamount' => intval($ceamt * 100),
                'paymentmethod' => 'card',
                'transactionType' => 'Payment',
                'connectionmode' => 'redirect',
                'currencycode' => '566',
                'customer' => $customer,
                'product' => array($product));

            $payload = json_encode($fields);
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $baseurl . "/api/v3/Payment/SetRequest");
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 3);
            curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json',
                "Authorization: Bearer {$access_token}",));
            curl_setopt($ch, CURLOPT_TIMEOUT, 20);
            $response = curl_exec($ch);
            $responseObject = json_encode($response);

            if ($responseObject['status']['statusCode'] == "201") {
                $redirect_url = $responseObject['redirectUri'];
                $error = false;
            } else {
                $error = true;
                $error_detail = 'Register transaction error:' . $responseObject['error'];
            };

            // globalpay Args
            $globalpay_args = array(
                'gp_error' => $error,
                'gp_errorDetail' => $error_detail,
                'gp_redirectUrl' => $redirect_url,
            );

            $globalpay_args = apply_filters('woocommerce_globalpay_args', $globalpay_args);
            return $globalpay_args;
        }

        /**
         * Generate the Globalpay Payment button link
         **/
        function generate_globalpay_form($order_id)
        {
            global $woocommerce;

            $order = new wc_get_order($order_id);

            $globalpay_args = $this->get_globalpay_args($order);

            $globalpay_args_object = json_decode(json_encode((object)$globalpay_args), FALSE);

            if ($globalpay_args_object->gp_error) {
                return $globalpay_args_object->gp_errorDetail;
            } else {
                return '<a class="button-alt" href="' . esc_url($globalpay_args_object->gp_redirectUrl) . '">' . __('Make Payment', 'woocommerce') . '</a>
					<a class="button cancel" href="' . esc_url($order->get_cancel_order_url()) . '">' . __('Cancel order &amp; restore cart', 'woocommerce') . '</a>';
            }

        }

        /**
         * Process the payment and return the result
         **/
        function process_payment($order_id)
        {
            $order = new WC_Order($order_id);
            return array(
                'result' => 'success',
                'redirect' => $order->get_checkout_payment_url(true)
            );
        }

        /**
         * Output for the order received page.
         **/
        function receipt_page($order)
        {
            echo '<p></br>' . __('Thank you for your order, please click the button below to make payment.', 'woocommerce') . '</p>';
            echo $this->generate_globalpay_form($order);
        }


        /**
         * Verify Transaction
         **/
        function check_globalpay_response($posted)
        {
            global $woocommerce;
            function getStatus($transref, $mertid, $baseurl, $orderid)
            {
                $fields = array('merchantid' => $mertid,
                    'merchantreference' => $orderid,
                    'transactionreference' => $transref);


                $payload = json_encode($fields);
                $ch = curl_init();
                curl_setopt($ch, CURLOPT_URL, $baseurl . "/api/v3/Payment/Retrieve");
                curl_setopt($ch, CURLOPT_POST, 1);
                curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 3);
                curl_setopt($ch, CURLOPT_TIMEOUT, 20);

                $response = curl_exec($ch);
                $err = curl_error($ch);
                $responseObject = json_decode($response, true);

                return $responseObject;
            }

            session_start();
            // this shows how you can retrieve the transaction status via the api
            $transref = $_SESSION['transref'];

            if ($_SESSION['urlmode'] == 'yes') {
                $baseurl = $this->baseurl_live;
            } else {
                $baseurl = $this->baseurl_test;
            };


            $raw_response = getStatus($transref, $this->MerchantId, $baseurl, $_SESSION['order_id']);

            if (array_key_exists('status', $raw_response) && array_key_exists('status', $raw_response['statusCode']) && ($raw_response['status']['statusCode'] === '200')) {
                $returned_status = "Transaction Successful";
            } else if (array_key_exists('data', $raw_response) && array_key_exists('status', $raw_response['data']) && ($raw_response['data']['status'] != '200')) {
                $returned_status = "Transaction failed. Contact support@globalpay.com for more information.";
            } else {
                $returned_status = "We can not process your transaction as at this time pls try again later";
            }


            $order_id = (int)$_SESSION['order_id'];
            $order = new WC_Order($order_id);
            $message = 'Thank you for shopping with us.<br />' . 'Payment Status:  ' . $returned_status . '</br>' . 'Transaction Reference ID:    ' . $raw_response['transactionreference'];

            if ($returned_status == "Transaction Successful") {

                $order->update_status('Processing', '');
                $order->add_order_note('Payment Via Globalpay ');
                $order->reduce_order_stock();
                WC()->cart->empty_cart();
                $message_type = 'success';
            } else {

                $order->update_status('No Payment Received', '');

                $order->add_order_note('Payment Via Globalpay ');

                $message_type = 'notice';
            }


            if (function_exists('wc_add_notice')) {
                wc_add_notice($message, $message_type);
            } else // WC < 2.1
            {
                $woocommerce->add_error($message);
                $woocommerce->set_messages();
            }

            $redirect_url = get_permalink(wc_get_page_id('myaccount'));

            wp_safe_redirect($redirect_url);
            exit;


        }

    }


    function _globalpay_message()
    {
        if (is_order_received_page()) {
            $order_id = absint(get_query_var('order-received'));

            $globalpay_message = get_post_meta($order_id, '', false);
            $message = $globalpay_message['message'];
            $message_type = $globalpay_message['message_type'];

            delete_post_meta($order_id, '__globalpay_message');

            if (!empty($globalpay_message)) {
                wc_add_notice($message, $message_type);
            }
        }
    }

    add_action('wp', '_globalpay_message');


    /**
     * Add Globalpay Gateway to WC
     **/
    function woocommerce_add_globalpay_gateway($methods)
    {
        $methods[] = 'WC_Globalpay_Gateway';
        return $methods;
    }

    add_filter('woocommerce_payment_gateways', 'woocommerce_add_globalpay_gateway');


    /**
     * only add the naira currency and symbol if WC versions is less than 2.1
     */
    if (version_compare(WOOCOMMERCE_VERSION, "2.1") <= 0) {

        /**
         * Add NGN as a currency in WC
         **/
        add_filter('woocommerce_currencies', '_add_my_currency');

        if (!function_exists('_add_my_currency')) {
            function _add_my_currency($currencies)
            {
                $currencies['NGN'] = __('Naira', 'woocommerce');
                return $currencies;
            }
        }

        /**
         * Enable the naira currency symbol in WC
         **/
        add_filter('woocommerce_currency_symbol', '_add_my_currency_symbol', 10, 2);

        if (!function_exists('_add_my_currency_symbol')) {
            function _add_my_currency_symbol($currency_symbol, $currency)
            {
                switch ($currency) {
                    case 'NGN':
                        $currency_symbol = '&#8358; ';
                        break;
                }
                return $currency_symbol;
            }
        }
    }


    /**
     * Add Settings link to the plugin entry in the plugins menu for WC below 2.1
     **/
    if (version_compare(WOOCOMMERCE_VERSION, "2.1") <= 0) {

        add_filter('plugin_action_links', '_globalpay_plugin_action_links', 10, 2);

        function _globalpay_plugin_action_links($links, $file)
        {
            static $this_plugin;

            if (!$this_plugin) {
                $this_plugin = plugin_basename(__FILE__);
            }

            if ($file == $this_plugin) {
                $settings_link = '<a href="' . get_bloginfo('wpurl') . '/wp-admin/admin.php?page=woocommerce_settings&tab=payment_gateways&section=WC_Globalpay_Gateway">Settings</a>';
                array_unshift($links, $settings_link);
            }
            return $links;
        }
    } /**
     * Add Settings link to the plugin entry in the plugins menu for WC 2.1 and above
     **/
    else {
        add_filter('plugin_action_links', '_globalpay_plugin_action_links', 10, 2);

        function _globalpay_plugin_action_links($links, $file)
        {
            static $this_plugin;

            if (!$this_plugin) {
                $this_plugin = plugin_basename(__FILE__);
            }

            if ($file == $this_plugin) {
                $settings_link = '<a href="' . get_bloginfo('wpurl') . '/wp-admin/admin.php?page=wc-settings&tab=checkout&section=wc_globalpay_gateway">Settings</a>';
                array_unshift($links, $settings_link);
            }
            return $links;
        }
    }
}