<?php
/*
* 2007-2015 PrestaShop
*
* NOTICE OF LICENSE
*
* This source file is subject to the Academic Free License (AFL 3.0)
* that is bundled with this package in the file LICENSE.txt.
* It is also available through the world-wide-web at this URL:
* http://opensource.org/licenses/afl-3.0.php
* If you did not receive a copy of the license and are unable to
* obtain it through the world-wide-web, please send an email
* to license@prestashop.com so we can send you a copy immediately.
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade PrestaShop to newer
* versions in the future. If you wish to customize PrestaShop for your
* needs please refer to http://www.prestashop.com for more information.
*
*  @author PrestaShop SA <contact@prestashop.com>
*  @copyright  2007-2015 PrestaShop SA
*  @license    http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
*  International Registered Trademark & Property of PrestaShop SA
*/

use PrestaShop\PrestaShop\Core\Payment\PaymentOption;

if (!defined('_PS_VERSION_')) {
    exit;
}

class Globalpay extends PaymentModule
{
    private $_html = '';
    private $_postErrors = array();

    public $details;
    public $owner;
    public $address;
    public $extra_mail_vars;
    
    public function __construct()
    {
        $this->name = 'globalpay';
        $this->tab = 'payments_gateways';
        $this->version = '1.0.2';
        $this->ps_versions_compliancy = array('min' => '1.7', 'max' => _PS_VERSION_);
        $this->author = 'Globalpay';
        $this->controllers = array('payment', 'validation');
        $this->is_eu_compatible = 0;
        #$this->module_key = '7bd648045911885fe8a9a3c6f550d76e';

        $this->currencies = true;
        $this->currencies_mode = 'checkbox';

        $config = Configuration::getMultiple(array('GLOBALPAY_TEST_CLIENT_SECRET','GLOBALPAY_TEST_CLIENT_ID','GLOBALPAY_LIVE_CLIENT_SECRET','GLOBALPAY_LIVE_CLIENT_ID','GLOBALPAY_MODE'));
     
        $this->bootstrap = true;
        parent::__construct();

        $this->displayName = $this->trans('Globalpay', array(), 'Modules.Globalpay.Admin');
        $this->description = $this->trans('Accept payments for your products via Globalpay.', array(), 'Modules.Globalpay.Admin');
        $this->confirmUninstall = $this->trans('Are you sure about removing these details?', array(), 'Modules.Globalpay.Admin');

        if (!isset($this->owner) || !isset($this->details) || !isset($this->address)) {
            $this->warning = $this->trans('Account owner and account details must be configured before using this module.', array(), 'Modules.Globalpay.Admin');
        }
        if (!count(Currency::checkPaymentCurrencies($this->id))) {
            $this->warning = $this->trans('No currency has been set for this module.', array(), 'Modules.Globalpay.Admin');
        }

        $this->extra_mail_vars = array(
            '{globalpay_owner}' => Configuration::get('GLOBALPAY_USERNAME'),
            '{globalpay_details}' => nl2br(Configuration::get('GLOBALPAY_DETAILS'))
        );
    }

    public function install()
    {
        if (!parent::install() || !$this->registerHook('paymentReturn') || !$this->registerHook('paymentOptions') || !$this->registerHook('header')) {
            return false;
        }

        // TODO : Cek insert new state, Custom CSS
        $newState = new OrderState();
        
        $newState->send_email = true;
        $newState->module_name = $this->name;
        $newState->invoice = true;
        $newState->color = "#E3000F";
        $newState->unremovable = false;
        $newState->logable = true;
        $newState->delivery = false;
        $newState->hidden = false;
        $newState->shipped = false;
        $newState->paid = true;
        $newState->delete = false;

        $languages = Language::getLanguages(true);
        foreach ($languages as $lang) {
            if ($lang['iso_code'] == 'id') {
                $newState->name[(int)$lang['id_lang']] = 'May Anibaba via Globalpay';
            } else {
                $newState->name[(int)$lang['id_lang']] = 'Payment successful';
            }
            $newState->template = "globalpay";
        }

        if ($newState->add()) {
            Configuration::updateValue('PS_OS_GLOBALPAY', $newState->id);
            copy(dirname(__FILE__).'/logo.png', _PS_IMG_DIR_.'tmp/order_state_mini_'.(int)$newState->id.'_1.png');
        } else {
            return false;
        }

        return true;
    }

    public function uninstall()
    {

        if (!Configuration::deleteByName('GLOBALPAY_TEST_CLIENT_SECRET')
            || !Configuration::deleteByName('GLOBALPAY_TEST_CLIENT_ID')
            || !Configuration::deleteByName('GLOBALPAY_LIVE_CLIENT_SECRET')
            || !Configuration::deleteByName('GLOBALPAY_LIVE_CLIENT_ID')
            || !Configuration::deleteByName('GLOBALPAY_MERCHANT_ID')
            || !parent::uninstall()
        ) {
            return false;
        }
        return true;
    }

    protected function _postProcess()
    {
        if (Tools::isSubmit('btnSubmit')) {
            Configuration::updateValue('GLOBALPAY_TEST_CLIENT_SECRET', Tools::getValue('GLOBALPAY_TEST_CLIENT_SECRET'));
            Configuration::updateValue('GLOBALPAY_TEST_CLIENT_ID', Tools::getValue('GLOBALPAY_TEST_CLIENT_ID'));
            Configuration::updateValue('GLOBALPAY_LIVE_CLIENT_SECRET', Tools::getValue('GLOBALPAY_LIVE_CLIENT_SECRET'));
            Configuration::updateValue('GLOBALPAY_LIVE_CLIENT_ID', Tools::getValue('GLOBALPAY_LIVE_CLIENT_ID'));
            Configuration::updateValue('GLOBALPAY_MODE', Tools::getValue('GLOBALPAY_MODE'));
            Configuration::updateValue('GLOBALPAY_MERCHANT_ID', Tools::getValue('GLOBALPAY_MERCHANT_ID'));
        }
        $this->_html .= $this->displayConfirmation($this->trans('Settings updated', array(), 'Admin.Global'));
    }

    private function _displayGlobalpay()
    {
        return $this->display(__FILE__, 'infos.tpl');
    }

    public function addJsRC($js_uri)
    {
        $this->context->controller->addJS($js_uri);
    }

    public function getContent()
    {
        if (Tools::isSubmit('btnSubmit')) {
            if (!count($this->_postErrors)) {
                $this->_postProcess();
            } else {
                foreach ($this->_postErrors as $err) {
                    $this->_html .= $this->displayError($err);
                }
            }
        } else {
            $this->_html .= '<br />';
        }

        $this->_html .= $this->_displayGlobalpay();
        $this->_html .= $this->renderForm();

        return $this->_html;
    }

    public function hookPaymentOptions($params)
    {
        if (!$this->active) {
            return;
        }

        if (!$this->checkCurrency($params['cart'])) {
            return;
        }
        if (!$this->checkCurrencyNGN($params['cart'])) {
            return;
        }
        $config = $this->getConfigFieldsValues();
        
        if ($config['GLOBALPAY_MODE'] == 1) {
            $id = $config['GLOBALPAY_TEST_CLIENT_ID'];
            $secret = $config['GLOBALPAY_TEST_CLIENT_SECRET'];
            $merchant_id = $config['GLOBALPAY_MERCHANT_ID'];
        } else {
            $id = $config['GLOBALPAY_LIVE_CLIENT_ID'];
            $secret = $config['GLOBALPAY_LIVE_CLIENT_SECRET'];
            $merchant_id = $config['GLOBALPAY_MERCHANT_ID'];
        }
        
        if ($id == '') {
            return;
        }
        $gateway_chosen = 'none';
        if (Tools::getValue('gateway') == 'globalpay') {
            $cart = $this->context->cart;
            $gateway_chosen = 'globalpay';
            $customer = new Customer((int)($cart->id_customer));
            $amount = $cart->getOrderTotal(true, Cart::BOTH);
            $currency_order = new Currency($cart->id_currency);
            $params = array(
              "reference"   => 'order_'.$params['cart']->id.'_'.time(),
              "amount"      => number_format($amount, 2),
              "pcolor"      => '',
              "scolor"      => '',
              "total_amount"=> $amount*100,
              "client_id"   => $id,
              "client_secret"  => $secret,
              "merchant_id" =>  $merchant_id,
              "currency"    => '566',
              "email"       => $customer->email,
            );
            $this->context->smarty->assign(
                array(
                'gateway_chosen' => 'globalpay',
                'form_url'       => $this->context->link->getModuleLink($this->name, 'globalpaysuccess', array(), true),
                )
            );
            $this->context->smarty->assign(
                $params
            );
        }
            
        $newOption = new PaymentOption();
        $newOption->setCallToActionText($this->trans('Globalpay (Debit/credit cards)', array(), 'Modules.Globalpay.Shop'))
            ->setAction($this->context->link->getModuleLink($this->name, 'validation', array(), true))
            ->setAdditionalInformation($this->context->smarty->fetch('module:globalpay/views/templates/hook/intro.tpl'))
            ->setLogo(Media::getMediaPath(_PS_MODULE_DIR_.$this->name.'/globalpay_logos.png'))
            ->setInputs(
                array(
                  'wcst_iframe' => array(
                  'name' =>'wcst_iframe',
                  'type' =>'hidden',
                  'value' =>'1',
                  )
                )
            );
        if ($gateway_chosen == 'globalpay') {
                $newOption->setAdditionalInformation(
                    $this->context->smarty->fetch('module:globalpay/views/templates/front/embedded.tpl')
                );
        }
        $payment_options = [
            $newOption,
        ];

        return $payment_options;
    }

    public function hookPaymentReturn($params)
    {
        if (!$this->active) {
            return;
        }

        $state = $params['order']->getCurrentState();
        $reference = Tools::getValue('transactionreference');
        if ($reference == "" || $reference == NULL) {
            $reference = $params['order']->reference;
        }
        if (in_array(
            $state,
            array(
                Configuration::get('PS_OS_GLOBALPAY'),
                Configuration::get('PS_OS_OUTOFSTOCK'),
                Configuration::get('PS_OS_OUTOFSTOCK_UNPAID'),
            )
        )
        ) {
            $globalpayOwner = $this->owner;
            $globalpayDetails = $this->details;
            $globalpayAddress = $this->address;
           
            $this->smarty->assign(
                array(
                'shop_name' => $this->context->shop->name,
                'total' => Tools::displayPrice(
                    $params['order']->getOrdersTotalPaid(),
                    new Currency($params['order']->id_currency),
                    false
                ),
                'globalpayDetails' => $globalpayDetails,
                'globalpayAddress' => $globalpayAddress,
                'globalpayOwner' => $globalpayOwner,
                'status' => 'ok',
                'reference' => $reference,
                'contact_url' => $this->context->link->getPageLink('contact', true)
                )
            );
        } else {
            $this->smarty->assign(
                array(
                    'status' => 'failed',
                    'contact_url' => $this->context->link->getPageLink('contact', true),
                )
            );
        }

        return $this->fetch('module:globalpay/views/templates/hook/payment_return.tpl');
    }

    public function checkCurrency($cart)
    {
        $currency_order = new Currency($cart->id_currency);
        $currencies_module = $this->getCurrency($cart->id_currency);

        if (is_array($currencies_module)) {
            foreach ($currencies_module as $currency_module) {
                if ($currency_order->id == $currency_module['id_currency']) {
                    return true;
                }
            }
        }
        return false;
    }

    public function checkCurrencyNGN($cart)
    {
        $currency_order = new Currency($cart->id_currency);
        if ($currency_order->iso_code == 'NGN') {
            return true;
        }
        return false;
    }

    public function renderForm()
    {
        $fields_form = array(
            'form' => array(
                'legend' => array(
                    'title' => $this->trans('User details', array(), 'Modules.Globalpay.Admin'),
                    'icon' => 'icon-user'
                ),
        
                'input' => array(
                    array(
                        'type' => 'switch',
                        'label' => $this->trans('Test Mode', array(), 'Modules.Globalpay.Admin'),
                        'name' => 'GLOBALPAY_MODE',
                        'is_bool' => true,
                        'required' => true,
                         'values' =>array(
                            array(
                                'id' => 'active_on',
                                'value' => true,
                                'label' => $this->trans('Test', array(), 'Modules.Globalpay.Admin')
                            ),array(
                                'id' => 'active_off',
                                'value' => false,
                                'label' => $this->trans('False', array(), 'Modules.Globalpay.Admin')
                            )
                        ),
                    ),
                    array(
                        'type' => 'text',
                        'label' => $this->trans('Test Client Secret', array(), 'Modules.Globalpay.Admin'),
                        'name' => 'GLOBALPAY_TEST_CLIENT_SECRET',
                       
                    ),
                      array(
                        'type' => 'text',
                        'label' => $this->trans('Test Client Id', array(), 'Modules.Globalpay.Admin'),
                        'name' => 'GLOBALPAY_TEST_CLIENT_ID',
                    ),
                    array(
                        'type' => 'text',
                        'label' => $this->trans('Live Client Secret', array(), 'Modules.Globalpay.Admin'),
                        'name' => 'GLOBALPAY_LIVE_CLIENT_SECRET',
                       
                    ),
                    array(
                        'type' => 'text',
                        'label' => $this->trans('Live Client Id', array(), 'Modules.Globalpay.Admin'),
                        'name' => 'GLOBALPAY_LIVE_CLIENT_ID',
                    ),  
                    array(
                        'type' => 'text',
                        'label' => $this->trans('Merchant Id', array(), 'Modules.Globalpay.Admin'),
                        'name' => 'GLOBALPAY_MERCHANT_ID',
                    ),  
                ),
                'submit' => array(
                    'title' => $this->trans('Save', array(), 'Admin.Actions'),
                )
            ),
        );
        $fields_form_customization = array();

        $helper = new HelperForm();
        $helper->show_toolbar = false;
        $helper->table = $this->table;
        $lang = new Language((int)Configuration::get('PS_LANG_DEFAULT'));
        $helper->default_form_language = $lang->id;
        $helper->allow_employee_form_lang = Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG') ? : 0;
        $this->fields_form = array();
        $helper->id = (int)Tools::getValue('id_carrier');
        $helper->identifier = $this->identifier;
        $helper->submit_action = 'btnSubmit';
        $helper->currentIndex = $this->context->link->getAdminLink('AdminModules', false).'&configure='
            .$this->name.'&tab_module='.$this->tab.'&module_name='.$this->name;
        $helper->token = Tools::getAdminTokenLite('AdminModules');
        $helper->tpl_vars = array(
            'fields_value' => $this->getConfigFieldsValues(),
            'languages' => $this->context->controller->getLanguages(),
            'id_language' => $this->context->language->id
        );

        return $helper->generateForm(array($fields_form, $fields_form_customization));
    }

    public function getConfigFieldsValues()
    {
        return array(
            'GLOBALPAY_TEST_CLIENT_ID' => Tools::getValue('GLOBALPAY_TEST_CLIENT_ID', Configuration::get('GLOBALPAY_TEST_CLIENT_ID')),
            'GLOBALPAY_TEST_CLIENT_SECRET' => Tools::getValue('GLOBALPAY_TEST_CLIENT_SECRET', Configuration::get('GLOBALPAY_TEST_CLIENT_SECRET')),
            'GLOBALPAY_LIVE_CLIENT_ID' => Tools::getValue('GLOBALPAY_LIVE_CLIENT_ID', Configuration::get('GLOBALPAY_LIVE_CLIENT_ID')),
            'GLOBALPAY_LIVE_CLIENT_SECRET' => Tools::getValue('GLOBALPAY_LIVE_CLIENT_SECRET', Configuration::get('GLOBALPAY_LIVE_CLIENT_SECRET')),
            'GLOBALPAY_MODE' => Tools::getValue('GLOBALPAY_MODE', Configuration::get('GLOBALPAY_MODE')),
            'GLOBALPAY_MERCHANT_ID' => Tools::getValue('GLOBALPAY_MERCHANT_ID', Configuration::get('GLOBALPAY_MERCHANT_ID')),
        );
    }
}
