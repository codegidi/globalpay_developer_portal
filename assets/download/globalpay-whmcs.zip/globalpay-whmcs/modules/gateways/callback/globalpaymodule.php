<?php
/**
 * WHMCS Sample Payment Callback File
 *
 * This sample file demonstrates how a payment gateway callback should be
 * handled within WHMCS.
 *
 * It demonstrates verifying that the payment gateway module is active,
 * validating an Invoice ID, checking for the existence of a Transaction ID,
 * Logging the Transaction for debugging and Adding Payment to an Invoice.
 *
 * For more information, please refer to the online documentation.
 *
 * @see https://developers.whmcs.com/payment-gateways/callbacks/
 *
 * @copyright Copyright (c) WHMCS Limited 2017
 * @license http://www.whmcs.com/license/ WHMCS Eula
 */

// Require libraries needed for gateway module functions.
require_once __DIR__ . '/../../../init.php';
require_once __DIR__ . '/../../../includes/gatewayfunctions.php';
require_once __DIR__ . '/../../../includes/invoicefunctions.php';

// Detect module name from filename.
$gatewayModuleName = basename(__FILE__, '.php');

// Fetch gateway configuration parameters.
$gatewayParams = getGatewayVariables($gatewayModuleName);

// Die if module is not active.
if (!$gatewayParams['type']) {
    die("Module Not Activated");
}

// Retrieve data returned in payment gateway callback
// Varies per payment gateway;
$transactionReference = $_GET["transactionreference"];

/**
 * Validate callback authenticity.
 *
 * Most payment gateways provide a method of verifying that a callback
 * originated from them. In the case of our example here, this is achieved by
 * way of a shared secret which is used to build and compare a hash.
 */
$testMode = $gatewayParams['testMode'];
$mertid = $gatewayParams['merchantID'];
$invoiceId = checkCbInvoiceID($invoiceId, $gatewayParams['name']);


if ($testMode == 'yes') {
    $baseurl = "http://globalpay.azurewebsites.net";;
} else {
    $baseurl = "http://globalpay.azurewebsites.net";;
};

$fields = array('merchantid' => $mertid,
    'merchantreference' => $invoiceId,
    'transactionreference' => $transactionReference);


$payload = json_encode($fields);
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $baseurl . "/api/v3/Payment/Retrieve");
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 3);
curl_setopt($ch, CURLOPT_TIMEOUT, 20);

$response = curl_exec($ch);
$err = curl_error($ch);
$raw_response = json_decode($response, true);
$success = false;

if (array_key_exists('status', $raw_response) && array_key_exists('status', $raw_response['statusCode']) && ($raw_response['status']['statusCode'] === '200')) {
    $returned_status = "Transaction Successful";
    $success = true;
} else if (array_key_exists('data', $raw_response) && array_key_exists('status', $raw_response['data']) && ($raw_response['data']['status'] != '200')) {
    $returned_status = "Transaction failed. Contact support@globalpay.com for more information.";
} else {
    $returned_status = "We can not process your transaction as at this time pls try again later";
}

$transactionStatus = $success ? 'Success' : 'Failure';


#checkCbTransID($transactionId);

logTransaction($gatewayParams['name'], $_POST, $transactionStatus);

if ($success) {

    addInvoicePayment(
        $invoiceId,
        $raw_response['transactionreference'],
        $raw_response['product'][0]['unitPrice'],
        '0',
        $gatewayModuleName
    );

}
