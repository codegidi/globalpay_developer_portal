<?php

if (!defined("WHMCS")) {
    die("This file cannot be accessed directly");
}

/**
 * Define module related meta data.
 *
 * Values returned here are used to determine module related capabilities and
 * settings.
 *
 * @see https://developers.whmcs.com/payment-gateways/meta-data-params/
 *
 * @return array
 */
function globalpaymodule_MetaData()
{
    return array(
        'DisplayName' => 'Globalpay Payment Gateway Module',
        'APIVersion' => '1.1', // Use API Version 1.1
        'DisableLocalCredtCardInput' => true,
        'TokenisedStorage' => false,
    );
}

/**
 * Define gateway configuration options.
 *
 * The fields you define here determine the configuration options that are
 * presented to administrator users when activating and configuring your
 * payment gateway module for use.
 *
 * Supported field types include:
 * * text
 * * password
 * * yesno
 * * dropdown
 * * radio
 * * textarea
 *
 * Examples of each field type and their possible configuration parameters are
 * provided in the sample function below.
 *
 * @return array
 */
function globalpaymodule_config()
{
    return array(
        'FriendlyName' => array(
            'Type' => 'System',
            'Value' => 'Globalpay Payment Gateway Module',
        ),

        'merchantID' => array(
            'FriendlyName' => 'Merchant ID',
            'Type' => 'text',
            'Size' => '25',
            'Default' => '',
            'Description' => 'Enter your merchant ID here',
        ),

        'clientIDTest' => array(
            'FriendlyName' => 'Client ID Test',
            'Type' => 'text',
            'Size' => '25',
            'Default' => '',
            'Description' => 'Enter your client ID Test here',
        ),

        'clientSecretTest' => array(
            'FriendlyName' => 'Client Secret Test',
            'Type' => 'password',
            'Size' => '25',
            'Default' => '',
            'Description' => 'Enter Client secret Test here',
        ),

        'clientIDLive' => array(
            'FriendlyName' => 'Client ID Test',
            'Type' => 'text',
            'Size' => '25',
            'Default' => '',
            'Description' => 'Enter your client ID Live here',
        ),

        'clientSecretLive' => array(
            'FriendlyName' => 'Client Secret Live',
            'Type' => 'password',
            'Size' => '25',
            'Default' => '',
            'Description' => 'Enter secret key here',
        ),

        'testMode' => array(
            'FriendlyName' => 'Test Mode',
            'Type' => 'yesno',
            'Description' => 'Tick to enable test mode',
        ),

    );
}

/**
 * Payment link.
 *
 * Required by third party payment gateway modules only.
 *
 * Defines the HTML output displayed on an invoice. Typically consists of an
 * HTML form that will take the user to the payment gateway endpoint.
 *
 * @param array $params Payment Gateway Module Parameters
 *
 * @see https://developers.whmcs.com/payment-gateways/third-party-gateway/
 *
 * @return string
 */
function globalpaymodule_link($params)
{
    // Gateway Configuration Parameters
    $merchantId = $params['merchantID'];
    $testMode = $params['testMode'];

    // Invoice Parameters
    $invoiceId = $params['invoiceid'];
    $description = $params["description"];
    $amount = $params['amount'];
    $currencyCode = $params['currency'];

    // Client Parameters
    $firstname = $params['clientdetails']['firstname'];
    $lastname = $params['clientdetails']['lastname'];
    $email = $params['clientdetails']['email'];
    $address1 = $params['clientdetails']['address1'];
    $address2 = $params['clientdetails']['address2'];
    $city = $params['clientdetails']['city'];
    $state = $params['clientdetails']['state'];
    $postcode = $params['clientdetails']['postcode'];
    $country = $params['clientdetails']['country'];
    $phone = $params['clientdetails']['phonenumber'];

    // System Parameters
    $companyName = $params['companyname'];
    $systemUrl = $params['systemurl'];
    $returnUrl = $params['returnurl'];
    $langPayNow = $params['langpaynow'];
    $moduleDisplayName = $params['name'];
    $moduleName = $params['paymentmethod'];
    $whmcsVersion = $params['whmcsVersion'];

    $url = 'https://www.demopaymentgateway.com/do.payment';


    if ($testMode=='yes') {
        $authurl = "http://globalpayauthserver.azurewebsites.net/connect/token";
        $baseurl = "http://globalpay.azurewebsites.net";
        $clientId = $params['clientIDTest'];
        $clientSecret = $params['clientSecretTest'];
    } else {
        $authurl = "http://globalpayauthserver.azurewebsites.net/connect/token";
        $baseurl = "http://globalpay.azurewebsites.net";
        $clientId = $params['clientIDTest'];
        $clientSecret = $params['clientSecretTest'];
    };

    $clientId = str_replace(' ', '', $clientId);
    $clientSecret = str_replace(' ', '', $clientSecret);

    //Client Authentication
    $body = array('client_id'=>$clientId,
        'grant_type'=>"client_credentials",
        'client_secret'=>$clientSecret);

    $postvars = '';
    foreach($body as $key=>$value) {
        $postvars .= $key . "=" . $value . "&";
    }

    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,$authurl);
    curl_setopt($ch,CURLOPT_POST, 1);
    curl_setopt($ch,CURLOPT_POSTFIELDS,$postvars);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch,CURLOPT_CONNECTTIMEOUT ,3);
    curl_setopt($ch,CURLOPT_TIMEOUT, 20);

    $response = curl_exec($ch);
    $err = curl_error($ch);

    $responseObject = json_decode($response, true);

    if (!isset($responseObject['error'])) {
        $access_token = $responseObject['access_token'];
        $error = false;
    } else {
        $error_detail = 'Access_token error:' . $responseObject['error'];
        $error = true;
    };


    //Register Transaction
    $customer = array('email'=> $email,
        'firstname'=> $firstname,
        'lastname'=> $lastname,
        'mobile'=> $phone);

    $product = array('name'=> 'order',
        'unitprice'=> $amount,
        'quantity'=>"1");

    $fields = array( 'returnurl'=>$systemUrl . '/modules/gateways/callback/' . $moduleName . '.php',
        'customerip'=>'127.0.0.1',
        'merchantid'=>$merchantId,
        'merchantreference'=>$invoiceId,
        'description'=>$description,
        'totalamount'=>$amount,
        'paymentmethod'=>'card',
        'transactionType'=>'Payment',
        'connectionmode'=>'redirect',
        'currencycode'=>'566',
        'customer'=>$customer,
        'product'=>array($product));

    $payload = json_encode($fields);
    $ch2 = curl_init();
    curl_setopt($ch2,CURLOPT_URL,$baseurl . "/api/v3/Payment/SetRequest");
    curl_setopt($ch2,CURLOPT_POST, 1);
    curl_setopt($ch2,CURLOPT_POSTFIELDS,$payload);
    curl_setopt($ch2,CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch2,CURLOPT_CONNECTTIMEOUT ,3);
    curl_setopt( $ch2, CURLOPT_HTTPHEADER, array('Content-Type:application/json',
        "Authorization: Bearer {$access_token}",));
    curl_setopt($ch,CURLOPT_TIMEOUT, 20);
    $response = curl_exec($ch2);
    $responseObject = json_encode($response);

    if ($responseObject['status']['statusCode']=="201") {
        $redirect_url = $responseObject['redirectUri'];
        $error = false;
    } else {
        $error = true;
        $error_detail = 'Register transaction error:' . $responseObject['error'];
    };


    if($error){
        $htmlOutput = "Globalpay error: " . $error_detail;
    } else {
        $htmlOutput = '<a class="button-alt" href="' . $redirect_url . '">' . $langPayNow . '</a>';
    }


    return $htmlOutput;


//    $postfields = array();
//    $postfields['username'] = $username;
//    $postfields['invoice_id'] = $invoiceId;
//    $postfields['description'] = $description;
//    $postfields['amount'] = $amount;
//    $postfields['currency'] = $currencyCode;
//    $postfields['first_name'] = $firstname;
//    $postfields['last_name'] = $lastname;
//    $postfields['email'] = $email;
//    $postfields['address1'] = $address1;
//    $postfields['address2'] = $address2;
//    $postfields['city'] = $city;
//    $postfields['state'] = $state;
//    $postfields['postcode'] = $postcode;
//    $postfields['country'] = $country;
//    $postfields['phone'] = $phone;
//    $postfields['callback_url'] = $systemUrl . '/modules/gateways/callback/' . $moduleName . '.php';
//    $postfields['return_url'] = $returnUrl;


}

